def init():
    global model


def run(raw_data):
    return "New Model B"
